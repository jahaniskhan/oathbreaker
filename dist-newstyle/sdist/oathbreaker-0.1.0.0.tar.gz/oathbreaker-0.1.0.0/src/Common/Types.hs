module Common.Types (
    AcquisitionConfig(..),
    SignalSource(..),
    SimulatedSignal(..),
    AcquisitionError(..),
    Anomaly(..)
) where

-- Removed unused import of Data.Complex
-- If only instances are needed, import it as follows:
import Data.Complex ()  -- Import instances only

--import Data.IORef (IORef)

-- Define your data types here
data AcquisitionConfig = AcquisitionConfig
    { device        :: String
    , path          :: FilePath
    , sampleRate    :: Double
    , duration      :: Double
    , signalSource  :: SignalSource
    }

data SignalSource
    = SDR
    | Simulated SimulatedSignal
    deriving (Show, Eq)

data SimulatedSignal
    = WhiteNoise
    | Sine Double          -- Frequency
    | MultiTone [Double]
    | QPSK Double          -- Symbol Rate
    deriving (Show, Eq)

data AcquisitionError
    = SourceNotFound
    | InvalidConfig String
    | ParsingFailed String
    | InsufficientVariance
    deriving (Show, Eq)

data Anomaly = Anomaly
    { description :: String
    , severity    :: Double
    } deriving (Show, Eq)
