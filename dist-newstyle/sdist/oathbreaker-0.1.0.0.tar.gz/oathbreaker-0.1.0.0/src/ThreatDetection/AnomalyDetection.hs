{-# LANGUAGE OverloadedStrings #-}

module ThreatDetection.AnomalyDetection
    ( detectAnomalies
    , Anomaly(..)
    , AnomalyType(..)
    ) where

import Data.Complex (Complex(..), magnitude)
import RFProcessor.SpectralAnalysis (calculatePowerSpectralDensity, detectPeaks)
import Numeric.LinearAlgebra (Matrix, Vector, fromList, toList, eigSH)
import Math.FFT (dft)  -- Changed from 'fft' to 'dft'
import qualified Numeric.LinearAlgebra as LA
import Data.List (transpose, sort)
import Statistics.Sample (meanVariance)
import Control.Monad (replicateM)
import Data.Function (on)
import Data.List (minimumBy)
import qualified Math.FFT as FFT
import Data.List (sort)
import Data.Vector.Storable (Vector)
import qualified Data.Vector.Storable as V

-- | Represents an anomaly in the signal
data Anomaly = Anomaly
    { anomalyFrequencyBin :: Int
    , anomalyMagnitude    :: Double
    , anomalyType         :: AnomalyType
    , anomalyScore        :: Double  -- New field for anomaly score
    } deriving (Show, Eq)

-- | Types of anomalies
data AnomalyType = UnexpectedPeak | SignalDropout | NoiseBurst | SpectrumAnomaly | TimeFrequencyAnomaly
    deriving (Show, Eq)

-- | Main function to detect anomalies using various techniques
detectAnomalies :: [Complex Double] -> Double -> Int -> Int -> [Anomaly]
detectAnomalies signal baseThreshold scoreThreshold windowSize = 
    let psd = calculatePowerSpectralDensity signal
        stftResult = applySTFT signal 128
        weightedThreshold = calculateWeightedThreshold psd baseThreshold
        basicAnomalies = detectBasicAnomalies signal psd weightedThreshold
        stftAnomalies = detectAnomaliesSTFT stftResult weightedThreshold
        pcaAnomalies = detectSpectrumAnomaliesPCA psd weightedThreshold
        allAnomalies = basicAnomalies ++ stftAnomalies ++ pcaAnomalies
        scoredAnomalies = scoreAnomalies allAnomalies windowSize
    in filter (\a -> anomalyScore a > fromIntegral scoreThreshold) scoredAnomalies

-- | Calculate weighted threshold based on signal properties
calculateWeightedThreshold :: [Double] -> Double -> Double
calculateWeightedThreshold psd baseThreshold =
    let medianPSD = median psd
        madPSD = medianAbsoluteDeviation psd
    in baseThreshold * (medianPSD + 2 * madPSD)

-- | Calculate Median Absolute Deviation
medianAbsoluteDeviation :: [Double] -> Double
medianAbsoluteDeviation xs =
    let med = median xs
        deviations = map (\x -> abs (x - med)) xs
    in median deviations

-- | Detect basic anomalies (peaks, dropouts, bursts)
detectBasicAnomalies :: [Complex Double] -> [Double] -> Double -> [Anomaly]
detectBasicAnomalies signal psd threshold = 
    let peaks = detectPeaks psd 5
        avgMagnitude = sum psd / fromIntegral (length psd)
        localThresholds = calculateLocalThresholds psd
        unexpectedPeaks = [Anomaly i v UnexpectedPeak 1.0
                           | (i, v) <- peaks, 
                             v > (localThresholds !! i) * avgMagnitude]
        signalDropouts = detectSignalDropouts signal avgMagnitude
        noiseBursts = detectNoiseBursts signal avgMagnitude
    in unexpectedPeaks ++ signalDropouts ++ noiseBursts

-- | Apply STFT to a signal to analyze time-frequency characteristics
applySTFT :: [Complex Double] -> Int -> [[Complex Double]]
applySTFT signal windowSize =
    let windows = slidingWindows windowSize signal
    in map (LA.toList . FFT.dft . LA.fromList) windows  -- Use 'dft' instead of 'fft'

-- | Detect anomalies using STFT analysis
detectAnomaliesSTFT :: [[Complex Double]] -> Double -> [Anomaly]
detectAnomaliesSTFT stftResult threshold = 
    concatMap (detectAnomaliesInWindow threshold) (zip [0..] stftResult)

-- | Detect anomalies within a time window's frequency spectrum
detectAnomaliesInWindow :: Double -> (Int, [Complex Double]) -> [Anomaly]
detectAnomaliesInWindow threshold (windowIndex, spectrum) = 
    let magnitudes = map magnitude spectrum
        avgMagnitude = sum magnitudes / fromIntegral (length magnitudes)
        peaks = detectPeaks magnitudes 5
    in [Anomaly (windowIndex * 100 + i) v TimeFrequencyAnomaly 1.0
       | (i, v) <- peaks, v > threshold * avgMagnitude]

-- | Detect spectrum anomalies using PCA
detectSpectrumAnomaliesPCA :: [Double] -> Double -> [Anomaly]
detectSpectrumAnomaliesPCA psd threshold =
    let matrix = LA.fromList [psd]
        covarianceMatrix = calculateCovarianceMatrix matrix
        (eigenvalues, eigenvectors) = LA.eigSH (LA.sym covarianceMatrix)
        anomalies = filter (> threshold) (LA.toList eigenvalues)
    in [Anomaly i v SpectrumAnomaly 1.0 | (i, v) <- zip [0..] anomalies]

-- | Score anomalies based on their occurrence within a sliding window
scoreAnomalies :: [Anomaly] -> Int -> [Anomaly]
scoreAnomalies anomalies windowSize =
    let windows = slidingWindows windowSize anomalies
    in concatMap scoreWindow windows

-- | Score anomalies within a single window
scoreWindow :: [Anomaly] -> [Anomaly]
scoreWindow window =
    let totalScore = fromIntegral (length window)
        scorePerAnomaly = if null window then 0 else totalScore / fromIntegral (length window)
    in map (\a -> a { anomalyScore = anomalyScore a + scorePerAnomaly }) window

-- | Calculate local thresholds based on a sliding window of local variance
calculateLocalThresholds :: [Double] -> [Double]
calculateLocalThresholds psd =
    let windowSize = 10
        variances = map variance (slidingWindows windowSize psd)
        paddedVariances = replicate (windowSize `div` 2) (head variances) ++ 
                          variances ++ 
                          replicate (windowSize `div` 2) (last variances)
    in map (\v -> sqrt v * 3) paddedVariances

-- | Utility function to calculate variance
variance :: [Double] -> Double
variance xs = 
    let meanX = sum xs / fromIntegral (length xs)
    in sum (map (\x -> (x - meanX) ** 2) xs) / fromIntegral (length xs)

-- | Utility function to generate sliding windows from a list
slidingWindows :: Int -> [a] -> [[a]]
slidingWindows n xs
    | length xs < n = []
    | otherwise     = take n xs : slidingWindows n (tail xs)

-- | Detect signal dropouts
detectSignalDropouts :: [Complex Double] -> Double -> [Anomaly]
detectSignalDropouts signal avgMagnitude =
    let dropoutThreshold = avgMagnitude * 0.1
        dropouts = filter (\(i, v) -> magnitude v < dropoutThreshold) (zip [0..] signal)
    in [Anomaly i (magnitude v) SignalDropout 1.0 | (i, v) <- dropouts]

-- | Detect noise bursts
detectNoiseBursts :: [Complex Double] -> Double -> [Anomaly]
detectNoiseBursts signal avgMagnitude =
    let burstThreshold = avgMagnitude * 5.0
        bursts = filter (\(i, v) -> magnitude v > burstThreshold) (zip [0..] signal)
    in [Anomaly i (magnitude v) NoiseBurst 1.0 | (i, v) <- bursts]

-- Add these local definitions:
cov :: LA.Matrix Double -> LA.Matrix Double
cov matrix =
    let centered = LA.cmap (\x -> x - LA.sumElements matrix / fromIntegral (LA.size matrix)) matrix
        n = fromIntegral (LA.rows matrix - 1)
    in (LA.tr centered LA.<> centered) / n

fromSymmetric :: LA.Matrix Double -> LA.Matrix Double
fromSymmetric m = (m + LA.tr m) / 2

-- Update calculateCovarianceMatrix to use the local cov function
calculateCovarianceMatrix :: LA.Matrix Double -> LA.Matrix Double
calculateCovarianceMatrix matrix =
    let centered = LA.cmap (\x -> x - LA.sumElements matrix / fromIntegral (LA.size matrix)) matrix
        n = fromIntegral (LA.rows matrix - 1)
    in (LA.tr centered LA.<> centered) / n

median :: (Ord a, Fractional a) => [a] -> a
median xs
  | null xs = error "median of empty list"
  | odd len = sorted !! mid
  | otherwise = (sorted !! (mid - 1) + sorted !! mid) / 2
  where
    sorted = sort xs
    len = length sorted
    mid = len `div` 2
